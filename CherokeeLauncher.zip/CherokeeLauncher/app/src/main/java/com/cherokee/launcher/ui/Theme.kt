package com.cherokee.launcher.ui

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object UC {
    val BgTop = Color(0xFF2C2E48)
    val BgBottom = Color(0xFF12131E)
    val Panel = Color(0xFF161827)
    val Tile = Color(0xFF1A1C2D)
    val Border = Color(0xFF5B5F80)
    val BarBg = Color(0xFF0D0F18)
    val Accent = Color(0xFF2F7CF0)
    val AccentDark = Color(0xFF1747A8)
    val Muted = Color(0xFFB8C0E8)
    val Background = Brush.verticalGradient(listOf(BgTop, BgBottom))
    val ActiveTab = Brush.verticalGradient(listOf(AccentDark, Accent))
    val StatusBar = Brush.horizontalGradient(listOf(Color(0xFF3D3560), Color(0xFF5A4A85), Color(0xFF3D3560)))
}
