package com.cherokee.launcher

import android.appwidget.AppWidgetHost
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.cherokee.launcher.data.AppRepo
import com.cherokee.launcher.ui.*

class MainActivity : ComponentActivity() {
    private lateinit var host: AppWidgetHost

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        host = AppWidgetHost(this, 1024)
        com.cherokee.launcher.data.Prefs.get(this, "obd_target")?.let {
            runCatching { com.cherokee.launcher.data.ObdManager.connect(this, it) }
        }
        setContent {
            val ctx = LocalContext.current
            var tab by remember { mutableStateOf(Tab.Home) }
            var apps by remember { mutableStateOf(emptyList<com.cherokee.launcher.data.AppInfo>()) }
            LaunchedEffect(Unit) { apps = AppRepo.load(ctx) }

            var panel by remember { mutableStateOf(false) }
            Box(Modifier.fillMaxSize().background(UC.Background)) {
            Column(Modifier.fillMaxSize()) {
                StatusBar(onToggle = { panel = !panel }, onOpen = { panel = true })
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (tab) {
                        Tab.Home -> HomeScreen(host)
                        Tab.Media -> LaunchSlotScreen("media", "Media", apps)
                        Tab.Comfort -> LaunchSlotScreen("comfort", "Comfort / Climate", apps)
                        Tab.Obd -> ObdScreen()
                        Tab.Nav -> LaunchSlotScreen("nav", "Navigation", apps)
                        Tab.CarPlay -> LaunchSlotScreen("carplay", "CarPlay", apps)
                        Tab.Vehicle -> VehicleScreen(apps)
                        Tab.Apps -> AppsScreen(apps)
                    }
                }
                BottomBar(tab) { tab = it; panel = false }
            }
            Column(Modifier.padding(top = 44.dp)) { ShortcutsPanel(panel, apps) { panel = false } }
            }
        }
    }

    override fun onStart() { super.onStart(); host.startListening() }
    override fun onStop() { super.onStop(); host.stopListening() }
}
