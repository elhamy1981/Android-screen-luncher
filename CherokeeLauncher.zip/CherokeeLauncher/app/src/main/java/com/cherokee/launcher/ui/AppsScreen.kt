package com.cherokee.launcher.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.cherokee.launcher.data.AppInfo
import com.cherokee.launcher.data.AppRepo

@Composable
fun AppsScreen(apps: List<AppInfo>) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var menuFor by remember { mutableStateOf<AppInfo?>(null) }
    val shown = remember(apps, query) { apps.filter { it.label.contains(query, ignoreCase = true) } }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Search apps") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = UC.Accent, unfocusedBorderColor = UC.Border
            )
        )
        AppGrid(shown, Modifier.weight(1f), onLongClick = { menuFor = it }) { AppRepo.launch(ctx, it.pkg) }
    }

    menuFor?.let { app ->
        AlertDialog(
            onDismissRequest = { menuFor = null },
            title = { Text(app.label) },
            text = { Text(app.pkg) },
            confirmButton = {
                TextButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    menuFor = null
                }) { Text("App info") }
            },
            dismissButton = {
                TextButton(onClick = {
                    ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    menuFor = null
                }) { Text("Uninstall") }
            }
        )
    }
}
