package com.cherokee.launcher.ui

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.cherokee.launcher.data.Prefs

/** Home: two widget slots (left/right) hosting real Android widgets. Long-press a widget to remove it. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(host: AppWidgetHost) {
    val ctx = LocalContext.current
    val mgr = remember { AppWidgetManager.getInstance(ctx) }
    var version by remember { mutableIntStateOf(0) }
    var pendingSlot by remember { mutableIntStateOf(-1) }
    var pendingId by remember { mutableIntStateOf(-1) }

    fun finish(slot: Int, id: Int) {
        Prefs.setInt(ctx, "widget_$slot", id); version++
    }
    fun bindOrConfigure(slot: Int, id: Int, launchConfig: (Intent) -> Unit) {
        val info = mgr.getAppWidgetInfo(id)
        if (info?.configure != null) {
            launchConfig(Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).setComponent(info.configure)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
        } else finish(slot, id)
    }

    val configLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) finish(pendingSlot, pendingId)
        else { host.deleteAppWidgetId(pendingId) }
    }
    val bindLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) bindOrConfigure(pendingSlot, pendingId) { configLauncher.launch(it) }
        else host.deleteAppWidgetId(pendingId)
    }
    val pickLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val id = r.data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingId) ?: pendingId
        if (r.resultCode != Activity.RESULT_OK) { host.deleteAppWidgetId(pendingId); return@rememberLauncherForActivityResult }
        pendingId = id
        val info = mgr.getAppWidgetInfo(id)
        if (info != null && !mgr.bindAppWidgetIdIfAllowed(id, info.provider)) {
            bindLauncher.launch(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider))
        } else bindOrConfigure(pendingSlot, id) { configLauncher.launch(it) }
    }

    fun addWidget(slot: Int) {
        pendingSlot = slot
        pendingId = host.allocateAppWidgetId()
        try {
            pickLauncher.launch(Intent(AppWidgetManager.ACTION_APPWIDGET_PICK)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingId))
        } catch (e: Exception) {
            host.deleteAppWidgetId(pendingId)
            Toast.makeText(ctx, "This head unit has no widget picker", Toast.LENGTH_LONG).show()
        }
    }

    Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        for (slot in 0..1) {
            val id = remember(version, slot) { Prefs.getInt(ctx, "widget_$slot") }
            Box(
                Modifier.weight(1f).fillMaxHeight()
                    .background(UC.Panel, RoundedCornerShape(6.dp))
                    .border(1.dp, UC.Border, RoundedCornerShape(6.dp))
                    .combinedClickable(
                        onClick = { if (id < 0) addWidget(slot) },
                        onLongClick = { if (id >= 0) { host.deleteAppWidgetId(id); Prefs.remove(ctx, "widget_$slot"); version++ } }
                    ),
                contentAlignment = Alignment.Center
            ) {
                val info = if (id >= 0) mgr.getAppWidgetInfo(id) else null
                if (info != null) {
                    AndroidView(factory = { host.createView(it, id, info) }, modifier = Modifier.fillMaxSize().padding(6.dp))
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.Add, "Add widget", tint = Color.White, modifier = Modifier.size(48.dp))
                        Text("Add Widget", color = Color.White, fontSize = 18.sp)
                    }
                }
            }
        }
    }
}
