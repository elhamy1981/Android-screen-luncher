package com.cherokee.launcher.ui

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.cherokee.launcher.data.ObdManager
import com.cherokee.launcher.data.Prefs

@Composable
private fun Gauge(label: String, value: String, unit: String, modifier: Modifier) {
    Column(
        modifier.background(UC.Tile, RoundedCornerShape(6.dp)).border(1.dp, UC.Border, RoundedCornerShape(6.dp)),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(label, color = UC.Muted, fontSize = 16.sp)
        Text(value, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
        Text(unit, color = UC.Muted, fontSize = 14.sp)
    }
}

@SuppressLint("MissingPermission")
@Composable
fun ObdScreen() {
    val ctx = LocalContext.current
    val d by ObdManager.data.collectAsState()
    var picking by remember { mutableStateOf(false) }

    fun hasPerm() = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) picking = true }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("OBD-II", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
            Text(d.status, color = if (d.connected) Color(0xFF6BE675) else UC.Muted, fontSize = 16.sp, modifier = Modifier.weight(1f))
            if (d.connected) OutlinedButton(onClick = { ObdManager.disconnect() }) { Text("Disconnect") }
            else Button(onClick = { if (hasPerm()) picking = true else permLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) }) { Text("Connect") }
        }
        for (row in listOf(
            listOf(Triple("Speed", d.speed?.toString(), "km/h"), Triple("RPM", d.rpm?.toString(), "rpm"), Triple("Coolant", d.coolant?.toString(), "°C")),
            listOf(Triple("Battery", d.voltage?.toString(), "V"), Triple("Fuel level", d.fuel?.toString(), "%"), Triple("Outside", d.ambient?.toString(), "°C"))
        )) {
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { (l, v, u) -> Gauge(l, v ?: "--", u, Modifier.weight(1f).fillMaxHeight()) }
            }
        }
    }

    if (picking) {
        val bonded = remember { ctx.getSystemService(BluetoothManager::class.java).adapter?.bondedDevices?.toList().orEmpty() }
        AlertDialog(
            onDismissRequest = { picking = false },
            title = { Text("Choose OBD adapter") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Pair the adapter in Android Bluetooth settings first (PIN usually 1234 or 0000).", fontSize = 13.sp)
                    bonded.forEach { dev ->
                        TextButton(onClick = {
                            Prefs.set(ctx, "obd_target", dev.address); ObdManager.connect(ctx, dev.address); picking = false
                        }) { Text("${dev.name ?: "Device"}  (${dev.address})") }
                    }
                    TextButton(onClick = {
                        Prefs.set(ctx, "obd_target", ObdManager.WIFI); ObdManager.connect(ctx, ObdManager.WIFI); picking = false
                    }) { Text("Wi-Fi adapter (192.168.0.10:35000)") }
                }
            },
            confirmButton = { TextButton(onClick = { picking = false }) { Text("Cancel") } }
        )
    }
}
