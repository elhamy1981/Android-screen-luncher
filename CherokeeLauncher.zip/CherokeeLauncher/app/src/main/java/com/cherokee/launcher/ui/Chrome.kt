package com.cherokee.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

enum class Tab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Filled.Home),
    Media("Media", Icons.Filled.MusicNote),
    Comfort("Comfort", Icons.Filled.Thermostat),
    Nav("Nav", Icons.Filled.Navigation),
    CarPlay("CarPlay", Icons.Filled.PlayCircle),
    Vehicle("Vehicle", Icons.Filled.DirectionsCar),
    Obd("OBD", Icons.Filled.Speed),
    Apps("Apps", Icons.Filled.Apps)
}

@Composable
fun StatusBar(onToggle: () -> Unit = {}, onOpen: () -> Unit = {}) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val obd by com.cherokee.launcher.data.ObdManager.data.collectAsState()
    val style = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
    Row(
        Modifier.fillMaxWidth().height(44.dp).background(UC.StatusBar)
            .pointerInput(Unit) { androidx.compose.foundation.gestures.detectVerticalDragGestures { _, dy -> if (dy > 8) onOpen() } }
            .clickable { onToggle() }
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(obd.voltage?.let { "$it V" } ?: "-- V", style = style, modifier = Modifier.weight(1f))
        Text(fmt.format(now), style = style.copy(fontSize = 22.sp))
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.End), verticalAlignment = Alignment.CenterVertically) {
            Text(obd.ambient?.let { "$it°C OUT" } ?: "--°C OUT", style = style)
            Text("OBD", style = style.copy(color = if (obd.connected) Color(0xFF6BE675) else UC.Muted))
        }
    }
}

@Composable
fun BottomBar(current: Tab, onSelect: (Tab) -> Unit) {
    Row(Modifier.fillMaxWidth().height(84.dp).background(UC.BarBg)) {
        Tab.values().forEach { t ->
            val active = t == current
            Column(
                Modifier.weight(1f).fillMaxHeight()
                    .then(if (active) Modifier.background(UC.ActiveTab) else Modifier)
                    .clickable { onSelect(t) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(t.icon, t.label, tint = Color.White, modifier = Modifier.size(32.dp))
                Text(t.label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
