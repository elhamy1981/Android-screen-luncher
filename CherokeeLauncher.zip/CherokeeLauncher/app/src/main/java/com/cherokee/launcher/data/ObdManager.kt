package com.cherokee.launcher.data

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.Closeable
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID

data class ObdData(
    val connected: Boolean = false,
    val status: String = "Not connected",
    val voltage: Double? = null,
    val rpm: Int? = null,
    val speed: Int? = null,
    val coolant: Int? = null,
    val ambient: Int? = null,
    val fuel: Int? = null
)

/** ELM327 over Bluetooth (SPP) or Wi-Fi (192.168.0.10:35000). Standard OBD-II PIDs only. */
object ObdManager {
    const val WIFI = "wifi"
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val _data = MutableStateFlow(ObdData())
    val data: StateFlow<ObdData> = _data.asStateFlow()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    @Volatile private var link: Closeable? = null

    @SuppressLint("MissingPermission")
    fun connect(ctx: Context, target: String) {
        disconnect()
        val app = ctx.applicationContext
        job = scope.launch {
            try {
                _data.value = ObdData(status = "Connecting…")
                val inp: InputStream
                val out: OutputStream
                if (target == WIFI) {
                    val s = Socket()
                    link = s
                    s.connect(InetSocketAddress("192.168.0.10", 35000), 5000)
                    inp = s.getInputStream(); out = s.getOutputStream()
                } else {
                    val adapter = app.getSystemService(BluetoothManager::class.java).adapter
                    val sock = adapter.getRemoteDevice(target).createRfcommSocketToServiceRecord(SPP)
                    link = sock
                    adapter.cancelDiscovery()
                    sock.connect()
                    inp = sock.inputStream; out = sock.outputStream
                }
                for (c in listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATSP0")) send(inp, out, c)
                _data.value = _data.value.copy(connected = true, status = "Connected")
                var n = 0
                while (isActive) {
                    var d = _data.value
                    Regex("([0-9]+\\.?[0-9]*)\\s*V").find(send(inp, out, "ATRV"))?.let { d = d.copy(voltage = it.groupValues[1].toDoubleOrNull()) }
                    bytes(send(inp, out, "010C"), "410C")?.takeIf { it.size >= 2 }?.let { d = d.copy(rpm = (it[0] * 256 + it[1]) / 4) }
                    bytes(send(inp, out, "010D"), "410D")?.firstOrNull()?.let { d = d.copy(speed = it) }
                    bytes(send(inp, out, "0105"), "4105")?.firstOrNull()?.let { d = d.copy(coolant = it - 40) }
                    if (n % 5 == 0) {
                        bytes(send(inp, out, "0146"), "4146")?.firstOrNull()?.let { d = d.copy(ambient = it - 40) }
                        bytes(send(inp, out, "012F"), "412F")?.firstOrNull()?.let { d = d.copy(fuel = it * 100 / 255) }
                    }
                    n++
                    _data.value = d
                    delay(250)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _data.value = ObdData(status = "Error: ${e.message ?: "connection failed"}")
            } finally {
                runCatching { link?.close() }
                link = null
            }
        }
    }

    fun disconnect() {
        job?.cancel(); job = null
        runCatching { link?.close() }; link = null
        _data.value = ObdData()
    }

    private suspend fun send(inp: InputStream, out: OutputStream, cmd: String): String {
        out.write((cmd + "\r").toByteArray()); out.flush()
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + 4000
        while (System.currentTimeMillis() < end) {
            if (inp.available() > 0) {
                val b = inp.read()
                if (b < 0 || b.toChar() == '>') break
                sb.append(b.toChar())
            } else delay(20)
        }
        return sb.toString().replace('\r', ' ').trim()
    }

    private fun bytes(resp: String, prefix: String): List<Int>? {
        val h = resp.replace(" ", "").uppercase()
        val i = h.indexOf(prefix)
        if (i < 0) return null
        return h.substring(i + prefix.length).chunked(2).filter { it.length == 2 }.mapNotNull { it.toIntOrNull(16) }
    }
}
