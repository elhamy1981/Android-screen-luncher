package com.cherokee.launcher.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cherokee.launcher.data.AppInfo
import com.cherokee.launcher.data.AppRepo
import com.cherokee.launcher.data.Prefs

@Composable
fun AppPickerDialog(apps: List<AppInfo>, title: String, onDismiss: () -> Unit, onPick: (AppInfo) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { AppGrid(apps, Modifier.height(320.dp).width(640.dp)) { onPick(it) } },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** Nav / Media / CarPlay: tapping the tab opens the chosen app. */
@Composable
fun LaunchSlotScreen(key: String, title: String, apps: List<AppInfo>) {
    val ctx = LocalContext.current
    // Comfort defaults to the Topway "AirCondition" app when it is installed.
    val autoPkg = if (key == "comfort") apps.firstOrNull { it.label.equals("AirCondition", true) }?.pkg else null
    var pkg by remember(key, autoPkg) { mutableStateOf(Prefs.get(ctx, key) ?: autoPkg) }
    var picking by remember(key, apps.isNotEmpty()) { mutableStateOf(pkg == null && apps.isNotEmpty()) }
    LaunchedEffect(key, pkg) { pkg?.let { AppRepo.launch(ctx, it) } }

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        val app = apps.firstOrNull { it.pkg == pkg }
        if (app != null) {
            Image(app.icon, app.label, Modifier.size(96.dp))
            Spacer(Modifier.height(12.dp))
            Text(app.label, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(onClick = { AppRepo.launch(ctx, app.pkg) }) { Text("Open") }
                OutlinedButton(onClick = { picking = true }) { Text("Change app") }
            }
        } else {
            Text("Choose the $title app", color = Color.White, fontSize = 24.sp)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { picking = true }) { Text("Choose") }
        }
    }
    if (picking) AppPickerDialog(apps, "Choose $title app", { picking = false }) {
        Prefs.set(ctx, key, it.pkg); pkg = it.pkg; picking = false; AppRepo.launch(ctx, it.pkg)
    }
}

private val vehicleSlots = listOf("Car Settings", "360 Camera", "Trip / Fuel", "Tire Pressure", "Radio", "Reverse Settings")

/** Vehicle: tiles you map to the head unit's own vendor apps (CAN data is vendor-specific). */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VehicleScreen(apps: List<AppInfo>) {
    val ctx = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    var pickIndex by remember { mutableStateOf<Int?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Vehicle", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        Text("Tap a tile to open. Long-press to change its app.", color = UC.Muted, fontSize = 15.sp)
        for (row in vehicleSlots.indices.chunked(3)) {
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { i ->
                    val pkg = remember(version, i) { Prefs.get(ctx, "veh_$i") }
                    val app = apps.firstOrNull { it.pkg == pkg }
                    Column(
                        Modifier.weight(1f).fillMaxHeight()
                            .background(UC.Tile, RoundedCornerShape(6.dp))
                            .border(1.dp, UC.Border, RoundedCornerShape(6.dp))
                            .combinedClickable(
                                onClick = { if (app != null) AppRepo.launch(ctx, app.pkg) else pickIndex = i },
                                onLongClick = { pickIndex = i }
                            ),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        if (app != null) Image(app.icon, app.label, Modifier.size(48.dp))
                        Text(vehicleSlots[i], color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text(app?.label ?: "Tap to assign", color = UC.Muted, fontSize = 13.sp)
                    }
                }
            }
        }
    }
    pickIndex?.let { i ->
        AppPickerDialog(apps, vehicleSlots[i], { pickIndex = null }) {
            Prefs.set(ctx, "veh_$i", it.pkg); version++; pickIndex = null
        }
    }
}
