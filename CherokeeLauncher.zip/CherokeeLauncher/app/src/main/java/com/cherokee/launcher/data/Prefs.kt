package com.cherokee.launcher.data

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    fun get(c: Context, key: String): String? = sp(c).getString(key, null)
    fun set(c: Context, key: String, value: String?) = sp(c).edit().apply {
        if (value == null) remove(key) else putString(key, value)
    }.apply()
    fun getInt(c: Context, key: String): Int = sp(c).getInt(key, -1)
    fun setInt(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()
    fun remove(c: Context, key: String) = sp(c).edit().remove(key).apply()
}
