package com.cherokee.launcher.ui

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cherokee.launcher.data.AppInfo
import com.cherokee.launcher.data.AppRepo
import com.cherokee.launcher.data.Prefs
import java.text.SimpleDateFormat
import java.util.*

private class Shortcut(val label: String, val icon: ImageVector, val prefKey: String? = null, val action: (Context) -> Unit = {})

private fun sys(action: String): (Context) -> Unit = { c ->
    try { c.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { Toast.makeText(c, "Not available on this unit", Toast.LENGTH_SHORT).show() }
}

private val shortcuts = listOf(
    Shortcut("Wi-Fi", Icons.Filled.Wifi, action = sys(Settings.ACTION_WIFI_SETTINGS)),
    Shortcut("Bluetooth", Icons.Filled.Bluetooth, action = sys(Settings.ACTION_BLUETOOTH_SETTINGS)),
    Shortcut("Hotspot", Icons.Filled.WifiTethering, action = sys(Settings.ACTION_WIRELESS_SETTINGS)),
    Shortcut("Display", Icons.Filled.Brightness6, action = sys(Settings.ACTION_DISPLAY_SETTINGS)),
    Shortcut("Sound", Icons.Filled.VolumeUp, action = sys(Settings.ACTION_SOUND_SETTINGS)),
    Shortcut("Settings", Icons.Filled.Settings, action = sys(Settings.ACTION_SETTINGS)),
    Shortcut("Camera", Icons.Filled.CameraAlt, prefKey = "sc_cam"),
    Shortcut("Voice", Icons.Filled.Mic, prefKey = "sc_voice")
)

/** Swipe-down panel: 4x2 shortcut grid. Camera and Voice are assignable (long-press to change). */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ShortcutsPanel(visible: Boolean, apps: List<AppInfo>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    var pickKey by remember { mutableStateOf<String?>(null) }
    val fmt = remember { SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()) }

    AnimatedVisibility(visible, enter = slideInVertically { -it }, exit = slideOutVertically { -it }) {
        Column(
            Modifier.fillMaxWidth().background(Color(0xF2161827))
                .border(1.dp, UC.Accent)
                .pointerInput(Unit) { detectVerticalDragGestures { _, dy -> if (dy < -8) onClose() } }
        ) {
            Text(fmt.format(Date()), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp))
            Text("Status Bar Shortcuts", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 24.dp, top = 8.dp))
            Text("Tap to open. Long-press Camera / Voice to choose an app.", color = UC.Muted, fontSize = 13.sp,
                modifier = Modifier.padding(start = 24.dp, bottom = 8.dp))
            for (row in shortcuts.chunked(4)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { s ->
                        val assigned = remember(version, s.prefKey) { s.prefKey?.let { Prefs.get(ctx, it) } }
                        Column(
                            Modifier.weight(1f).height(84.dp)
                                .background(UC.Tile, RoundedCornerShape(6.dp))
                                .border(1.dp, UC.Border, RoundedCornerShape(6.dp))
                                .combinedClickable(
                                    onClick = {
                                        if (s.prefKey == null) { s.action(ctx); onClose() }
                                        else if (assigned != null && AppRepo.launch(ctx, assigned)) onClose()
                                        else pickKey = s.prefKey
                                    },
                                    onLongClick = { s.prefKey?.let { pickKey = it } }
                                ),
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                        ) {
                            Icon(s.icon, s.label, tint = Color.White, modifier = Modifier.size(30.dp))
                            Text(s.label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            Box(Modifier.fillMaxWidth().height(36.dp).clickable { onClose() }, contentAlignment = Alignment.Center) {
                Box(Modifier.width(80.dp).height(4.dp).background(Color.White, RoundedCornerShape(2.dp)))
            }
        }
    }
    pickKey?.let { k ->
        AppPickerDialog(apps, "Choose app", { pickKey = null }) { Prefs.set(ctx, k, it.pkg); version++; pickKey = null }
    }
}
