# Cherokee Launcher (Jeep Grand Cherokee 2017, 8.4" Android head unit)

Kotlin + Jetpack Compose launcher styled after the factory screen layout.

Build: open this folder in Android Studio (Ladybug or newer), let it sync (it creates the Gradle wrapper), then Build > Build APK.
Install: `adb install app-debug.apk` or copy the APK to the unit, then press Home and choose "Cherokee Launcher" > Always.

Tabs
- Home: two slots that host real Android widgets (tap + to pick, long-press to remove).
- Media / Nav / CarPlay: tap the tab to open the app you chose for it (change via the Change app button).
- Vehicle: 6 tiles you map to the head unit's own vendor apps (car settings, 360 camera, trip, tires, radio, reverse settings).
- Apps: searchable grid; long-press for App info / Uninstall.

- Comfort: opens the head unit's own climate/car app that you choose (climate control over CAN is vendor-specific, so it is not controlled directly).
- OBD: connect an ELM327 adapter (paired Bluetooth, or Wi-Fi 192.168.0.10:35000). Shows speed, RPM, coolant, battery voltage, fuel level and outside temperature; battery voltage and outside temp also appear in the top bar. Reconnects automatically at launch.

- Swipe-down shortcuts: swipe down (or tap) the top bar for a 4x2 grid: Wi-Fi, Bluetooth, Hotspot, Display, Sound, Settings, plus Camera and Voice that you assign (long-press).

Not done yet: exact Uconnect artwork.
